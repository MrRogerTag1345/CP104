"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Chetas Patel
ID:     200679130
Email:  pate9130@mylaurier.ca
__updated__ = "2020-11-16"
------------------------------------------------------------------------
"""

from functions import calculate

expr = input("Enter an expression: ")

result = calculate(expr)

print(result)
