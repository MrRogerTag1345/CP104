"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Chetas Patel
ID:     200679130
Email:  pate9130@mylaurier.ca
__updated__ = "2020-11-16"
------------------------------------------------------------------------
"""

from functions import validate_code

product_code = input("Enter a product code: ")

validate_code(product_code)
