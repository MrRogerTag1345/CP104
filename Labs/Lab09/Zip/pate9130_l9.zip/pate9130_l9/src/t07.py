"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Chetas Patel
ID:     200679130
Email:  pate9130@mylaurier.ca
__updated__ = "2020-11-16"
------------------------------------------------------------------------
"""

from functions import vowel_count

s = input("Enter a string: ")

count = vowel_count(s)

print("There are {} vowels.".format(count))
