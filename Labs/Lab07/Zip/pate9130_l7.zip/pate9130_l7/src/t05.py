"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Chetas Patel
ID:     200679130
Email:  pate9130@mylaurier.ca
__updated__ = "2020-11-02"
------------------------------------------------------------------------
"""

from functions import positive_statistics

positive_statistics()
