"""
------------------------------------------------------------------------
t03.py

------------------------------------------------------------------------
Author: Chetas Patel
ID:     200679130
Email:  pate9130@mylaurier.ca
__updated__ = "2020-11-09"
------------------------------------------------------------------------
"""

from functions import get_digit_name

var = int(input("Number: "))

name = get_digit_name(var)

print(name)
