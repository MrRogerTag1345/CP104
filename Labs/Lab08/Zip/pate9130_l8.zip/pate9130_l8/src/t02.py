"""
------------------------------------------------------------------------
t02.py
------------------------------------------------------------------------
Author: Chetas Patel
ID:     200679130
Email:  pate9130@mylaurier.ca
__updated__ = "2020-11-09"
------------------------------------------------------------------------
"""

from functions import get_month_name

var_one = int(input("Enter a month: "))

name = get_month_name(var_one)

print(name)
