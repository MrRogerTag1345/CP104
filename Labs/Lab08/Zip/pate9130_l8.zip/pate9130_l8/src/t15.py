"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Chetas Patel
ID:     200679130
Email:  pate9130@mylaurier.ca
__updated__ = "2020-11-09"
------------------------------------------------------------------------
"""

from functions import symmetric_difference

v1 = [10, 3, 10, 3, 1]
v2 = [8, 2, 7, 3, 6, 10, 32, 99]

target = symmetric_difference(v1, v2)

print("Difference:", target)
