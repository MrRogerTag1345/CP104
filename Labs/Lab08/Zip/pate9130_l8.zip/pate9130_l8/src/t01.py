"""
------------------------------------------------------------------------
t01.py

------------------------------------------------------------------------
Author: Chetas Patel
ID:     200679130
Email:  pate9130@mylaurier.ca
__updated__ = "2020-11-09"
------------------------------------------------------------------------
"""

from functions import get_weekday_name

var_one = int(input("Day of the week: "))

name = get_weekday_name(var_one)

print(name)
