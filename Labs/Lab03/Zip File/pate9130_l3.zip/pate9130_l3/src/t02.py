"""
------------------------------------------------------------------------
t02.ty
This program prints out the lullaby Twinkle Twinkle Little Star, by Jane Taylor.
------------------------------------------------------------------------
Author: Chetas Patel
ID:     200679130
Email:  pate9130@mylaurier.ca
__updated__ = "2020-09-28"
------------------------------------------------------------------------
"""

# Prints the string.
print("'Twinkle Twinkle Little Star' by Jane Taylor")
print()
print("Twinkle, twinkle, little star,")
print("    How I wonder what you are!")
print("        Up above the world so high,")
print("        Like a diamond in the sky.")
print("Twinkle, twinkle, little star,")
print("    How I wonder what you are")
