"""
------------------------------------------------------------------------
t05.py
This program find the difference between the maximum and minimum values.
------------------------------------------------------------------------
Author: Chetas Patel
ID:     200679130
Email:  pate9130@mylaurier.ca
__updated__ = "2020-09-28"
------------------------------------------------------------------------
"""

# Input from the user.
minimum_input = int(input("Enter minimum: "))
maximum_input = int(input("Enter maximum: "))

# Compute to find the distance.
out_put = maximum_input - minimum_input

# Print output statement. 
print("The difference between {} and {} is {}".format(maximum_input, minimum_input, out_put))
