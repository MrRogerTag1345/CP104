"""
------------------------------------------------------------------------
t04.py
This program check serial number.
------------------------------------------------------------------------
Author: Chetas Patel
ID:     200679130
Email:  pate9130@mylaurier.ca
__updated__ = "2020-11-30"
------------------------------------------------------------------------
"""

# Import from functions.
from functions import valid_sn_file

# Open file.
var_one = open("serial_number.txt", "r")
var_two = open("output_t04_valid.txt", "w")
var_three = open("output_t04_invalid.txt", "w")
    
# Sends to the function.
valid_sn_file(var_one, var_two, var_three)
  
# Print statement.  
print("Valid SN are in the 'output_t04_valid.txt' ")
print("Invalid SN are in the 'output_t04_invalid.txt' ")

# Close file.    
var_one.close()
var_two.close()
var_three.close()
