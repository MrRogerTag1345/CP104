"""
------------------------------------------------------------------------
t03.py
This program finds the number of capital, and lowercase letters, numbers,
and whitespaces.
------------------------------------------------------------------------
Author: Chetas Patel
ID:     200679130
Email:  pate9130@mylaurier.ca
__updated__ = "2020-11-29"
------------------------------------------------------------------------
"""

# Import functions.
from functions import file_analysis

# Open file.
var_one = open("text.txt", "r")
var_two = open("output_t03.txt", "w")

# Send to the functions.
result = file_analysis(var_one)

# Print statement.
print("{}".format(result))

# Write to the file.
print("{}".format(result), file=var_two)

# Close the file.
var_one.close()
var_two.close()
