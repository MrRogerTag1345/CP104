"""
------------------------------------------------------------------------
t02.py
This program finds the median of a group.
------------------------------------------------------------------------
Author: Chetas Patel
ID:     200679130
Email:  pate9130@mylaurier.ca
__updated__ = "2020-11-30"
------------------------------------------------------------------------
"""
# Import from functions.
from functions import locate_median

# Open file.
var_one = open("numbers.txt")
var_two = open("output_t02.txt", "w")

# Send to functions.
listnum, median = locate_median(var_one)

# Print statement.
print("{}={}".format(listnum, median))

# Print to the file.
print("{}={}".format(listnum, median), file=var_two)

# Close file.
var_one.close()
var_two.close()
