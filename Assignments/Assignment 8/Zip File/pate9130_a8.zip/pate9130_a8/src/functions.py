"""
------------------------------------------------------------------------
functions.py
This is a functions file.
------------------------------------------------------------------------
Author: Chetas Patel
ID:     200679130
Email:  pate9130@mylaurier.ca
__updated__ = "2020-11-30"
------------------------------------------------------------------------
"""


# t01.py
def total_nums(fh):
    """
    -------------------------------------------------------
    This program finds numbers in string and computes the sum.
    Use: count = result, result2 = total_nums(var_one)
    -------------------------------------------------------
    Parameters:
        fh - file on hand (file handle - already open for reading)
    Returns:
        output - location to where the number are positioned (list of ints)
        sum - the sum of all the number in the string (int)
    ------------------------------------------------------
    """
    
    # Defining variables.
    output = []
    sum = 0
    line = fh.readline()
    temp = line.split()
    
    # For loop to run the length of the converted list from file line. 
    for i in range(len(temp)):
        # If checks is the position at i is a digit.
        if temp[i].isdigit() == True:
            sum += int(temp[i])
            output.append(int(temp[i]))
    
    # Return back to the main file.        
    return output, sum


# t02.py
def locate_median(fh):
    """
    -------------------------------------------------------
    Reads through text file and sums numbers encountered.
    Writes to another file called: output_t01.txt
    Use: listnum, median = locate_median(var_one)
    -------------------------------------------------------
    Parameters:
        fn - file to search (file - open for reading)
    Returns:
        med  - the sum of the integers encountered (int > 0)
        listnum - list of all positive integers 
    ------------------------------------------------------
    """
    # Declaring Variables.
    med = 0 
    listnum = [] 
    
    # For loop runs for all lines on the file.
    for line in fh:
        line = line.rstrip()
        temp = line.split(' ')
        # For loop runs for all values in temp.
        for i in temp:
            listnum.append(int(i))

    # Sorts the list.
    listnum.sort()

    # If statements to compare.
    if len(listnum) % 2 == 0:
        med = (listnum[len(listnum) / 2] + listnum[len(listnum) / 2 - 1]) / 2
    else:
        med = listnum[len(listnum) // 2]
    
    # Return back to the main file.
    return listnum, med


# t03.py
def file_analysis(fh):
    """
    -------------------------------------------------------
    This program counts the number of capital and lowercase letters, numbers, and whitespace.
    Use: result = file_analysis(var_one)
    -------------------------------------------------------
    Parameters:
        fh - file on hand (file handle - already open for reading)
        value - the value to count (str)
    Returns:
        list - list of the counts (list of int)
    ------------------------------------------------------
    """
    
    # Defining variables.
    counts = 0
    countl = 0
    countnum = 0
    countblank = 0
    list = []
    
    # For loop runs for all lines on the file.
    for line in fh:
        temp = (line.strip())
        # For loop runs for all elements of a single line on the file.
        for i in range(len(temp)):
            if temp[i].isupper() == True:
                counts += 1
                
            elif temp[i].islower() == True:
                countl += 1
                
            if temp[i].isdigit() == True:
                countnum += 1
                
            if temp[i].isspace() == True:
                countblank += 1
    
    # Appending the final results to a list.            
    list.append(counts)  
    list.append(countl)
    list.append(countnum)
    list.append(countblank)   
    
    # Return back to the main file.       
    return list


# t04.py
def is_valid(txt):
    """
    -------------------------------------------------------
    Reads through text file and sums numbers encountered.
    Writes to another file called: output_t04.txt
    Use: result = is_valid(line)
    -------------------------------------------------------
    Parameters:
        txt - string
    Returns:
        result - True if serial number is valid 
               - False if serial number is invalid
    -------------------------------------------------------
    """
    # Define Variables.
    txt = txt.strip()
    
    # If statement.
    if(len(txt)) != 11:
        result = False
    elif(txt[0] != "S" or txt[1] != "N" or txt[2] != "/"):
        result = False
    elif(txt[3].isdigit() == False or txt[4].isdigit() == False or txt[5].isdigit() == False or txt[6].isdigit() == False):
        result = False
    elif(txt[7] != "-"):
        result = False
    elif(txt[8].isdigit() == False or txt[9].isdigit() == False or txt[10].isdigit == False):
        result = False
    else:
        result = True
     
    # Return back to the main file.    
    return result

  
# t04.py
def valid_sn_file(var_one, var_two, var_three):
    """
    -------------------------------------------------------
    Reads through text file and sums numbers encountered.
    Writes to another file called
    Use: valid_sn_file(var_one, var_two, var_three)
    -------------------------------------------------------
    Parameters:
        var_one - file handle that contains a list of serial numbers 
        var_two - file handle outputted that contains all valid serial numbers
        var_three - file handle outputted that contains all invalid serial numbers
    Returns:
        None
    -------------------------------------------------------
    """
    # Defining Variables
    count_valid = 0
    count_invalid = 0
    
    # For loop
    for line in var_one:
        result = is_valid(line)
        # If statement
        if result == True:
            var_two.write(line)
            count_valid += 1

        else:
            var_three.write(line)
            count_invalid += 1
    
    # If statement.
    if count_valid == 0:
        var_two.write("None")
    if count_invalid == 0:
        var_three.write("None")

