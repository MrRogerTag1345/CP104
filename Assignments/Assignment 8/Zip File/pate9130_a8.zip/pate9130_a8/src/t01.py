"""
------------------------------------------------------------------------
t01.py
This program gets the sum of numbers in a string.
------------------------------------------------------------------------
Author: Chetas Patel
ID:     200679130
Email:  pate9130@mylaurier.ca
__updated__ = "2020-11-29"
------------------------------------------------------------------------
"""

# Import from functions.
from functions import total_nums

# Open file.
var_one = open("text_numbers.txt", "r")
var_two = open("output_t01.txt", "w")

# Send a file through a function.
result, result2 = total_nums(var_one)

# Printing.
print("{}".format(result))
print("{}".format(result2))

# Writing to a save file.
print("{}".format(result), file=var_two)
var_two.write(str(result2))

# Close the file.
var_one.close()
var_two.close()

