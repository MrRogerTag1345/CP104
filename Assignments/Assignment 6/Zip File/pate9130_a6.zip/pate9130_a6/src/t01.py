"""
------------------------------------------------------------------------
t01.py
This program takes positive integer and puts it in a array.
------------------------------------------------------------------------
Author: Chetas Patel
ID:     200679130
Email:  pate9130@mylaurier.ca
__updated__ = "2020-11-11"
------------------------------------------------------------------------
"""

# Import function.
from functions import read_positive

# Call the function.
list = read_positive()

# Print statement
print("List entered:", list)
