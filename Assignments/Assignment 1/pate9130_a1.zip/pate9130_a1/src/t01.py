"""
------------------------------------------------------------------------
t01.py
This program print's out strings.
------------------------------------------------------------------------
Author: Chetas Patel
ID:     200679130
Email:  pate9130@mylaurier.ca
__updated__ = "2020-09-20"
------------------------------------------------------------------------
"""

# Print functions printing strings.
print('What is "petabyte"?')
print("""A petabyte (PB)is a lot of data:
1 PB = 20 million 4 drawer filing cabinets filled with text
1.5 PB = size of 10 billion photos on facebook
20 PB = the amount of data processed by Google per day""")
print("that's a lot of data to handle. Big Data.")
print(""""You have enemies? Good. That means you've stood up for something, sometime in your life." Winston Churchill""")

