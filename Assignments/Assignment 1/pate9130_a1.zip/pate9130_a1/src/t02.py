"""
------------------------------------------------------------------------
t02.py
This program takes input and prints string.
------------------------------------------------------------------------
Author: Chetas Patel
ID:     200679130
Email:  pate9130@mylaurier.ca
__updated__ = "2020-09-19"
------------------------------------------------------------------------
"""

# Input from the user.
var_one = input("Enter your favourite course: ")
var_two = input("Enter the grade you hope to get: ")

# Prints the users response on in a string.
print("You hope to get", var_two, "in your favourite course", var_one + ".")
