"""
------------------------------------------------------------------------
t03.py
This program takes user input and prints string.
------------------------------------------------------------------------
Author: Chetas Patel
ID:     200679130
Email:  pate9130@mylaurier.ca
__updated__ = "2020-09-20"
------------------------------------------------------------------------
"""

# Input from the user.
var_one = input("What is first name? ")
var_two = input("What is last name? ")

# Prints the users response on in a string.
print("Welcome", var_one, var_two)
